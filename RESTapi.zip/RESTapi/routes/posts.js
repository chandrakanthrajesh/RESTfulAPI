const express = require('express');
const router = express.Router();
const userModel = require('../models/user')



//get route                                         
router.get('/',async (req,res)=>{
    
    try{
        const posts = await userModel.find();
        res.json(posts);
    }catch(err){
        res.json(err);
    }
});


//post route
router.post('/',async (req,res)=>{
    console.log(req.body)
    const model = new userModel({
        Name:req.body.name,             //unable to read the data from req.body.body
        Address:req.body.address
         
    });
    console.log(model);
    try{
    const savedModels = await model.save();
    res.json(savedModels)
    }catch(err){
    res.json(err)
    }
});


//find data route
router.get('/:id',async (req,res)=>{
    //console.log(req.params.id);
    try{
    const model1 = await userModel.findById(req.params.id);
    res.json(model1);
    }catch(error){
    res.json(error)
    }
});

//delete data route
router.delete('/:id',async (req,res)=>{
    try{
    const removeData = await userModel.remove({_id:req.params.id});
    res.json(removeData);
    }catch(error){
        res.json(error);
    }
});

//update data route
router.patch('/:id',async (req,res) =>{
    try{
    const updateData = await userModel.updateOne(
    {_id:req.params.id},
    {$set:{Address:req.body.Address}}
    );
    res.json(updateData);
    }catch(error){
        res.json(error);
    }
});

module.exports = router;