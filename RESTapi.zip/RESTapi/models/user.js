const mongoose = require('mongoose');

const userSchema = mongoose.Schema({
    Name: {
        type:String,
        required:true
    },
    Address: {
        type:String,
        required:true},
    date: {
        type:Date,
        default:Date.now
    }
});


module.exports = mongoose.model('ck',userSchema);