const express = require('express');
const app = express();
const mongoose = require('mongoose');
const postsRouter = require('./routes/posts');
const bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


//Connecting Mongoose to node js
mongoose.connect("mongodb://localhost:27017/RESTapi",
 { useNewUrlParser: true,
    useUnifiedTopology: true },
 (error)=>{
    if(!error){
        console.log('Successfully connected to MongoDB');
    }
    else{
        console.log("Error connecting to DB");
    }
});

//middleware
app.use('/post',postsRouter);

//Setting up server
app.listen(3000,function(req,res){
    console.log('Connection has been made on 3000');
});